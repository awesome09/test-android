package com.walloverss.bloggie

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

/**
 * Created by Avhinash on 3/4/2018.
 */
class BlogAdapter(val list: ArrayList<blog>) : RecyclerView.Adapter<BlogAdapter.ViewHolder>() {

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ViewHolder?, position: Int) {
        holder!!.textView.text = list[position].title
    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ViewHolder {
       val view = LayoutInflater.from(parent?.context).inflate(R.layout.blog_row,parent,false)
        return ViewHolder(view)
    }


    class ViewHolder(itemView:View) : RecyclerView.ViewHolder(itemView){
        var textView = (itemView).findViewById<TextView>(R.id.textt)

    }
}