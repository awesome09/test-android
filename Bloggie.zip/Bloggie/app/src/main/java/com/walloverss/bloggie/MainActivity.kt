package com.walloverss.bloggie

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    lateinit var UserDb:UserHelper
    lateinit var em:String
    lateinit  var ps:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        em = email.text.toString()
        ps = password.text.toString()
        btn_login.setOnClickListener({
            if (isValidate())
            {
                if (UserDb.checkUser(em,ps)){
                val intent = Intent(this,Content::class.java)
                startActivity(intent)}
            }


        })

        bt_register.setOnClickListener({
            val intent = Intent(this,Registerr::class.java)
            startActivity(intent)
        })
    }

    fun isValidate() : Boolean {

        if(!validEmail())
        {
            return false
        }

        if (!validPassword())
        {
            return false
        }

        Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show()

        return  true


    }


    fun validEmail() : Boolean
    {

        if (em.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(em).matches())
        {
          //  layout_email.setError("Enter a valid email address")
            Toast.makeText(this,"Please write correct email",Toast.LENGTH_SHORT).show()
            return false
        }
        else
        {
            layout_email.isErrorEnabled
        }
        return true

    }

    fun validPassword():Boolean
    {

        if (ps.isEmpty() || ps.length <6 || ps.length>12)
        {


            Toast.makeText(this,"Please enter password betwen 6 and 12 characters",Toast.LENGTH_SHORT).show()
            return  false
        }
        else
        {
            layout_password.isErrorEnabled
        }
        return true

    }



}

