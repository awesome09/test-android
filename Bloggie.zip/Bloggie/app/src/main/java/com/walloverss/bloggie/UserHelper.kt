package com.walloverss.bloggie

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.walloverss.bloggie.UserHelper.Statified.DB_NAME
import com.walloverss.bloggie.UserHelper.Statified.DB_VERSION

/**
 * Created by Avhinash on 3/4/2018.
 */
class UserHelper : SQLiteOpenHelper {

    object Statified{
        val DB_NAME = "user.db"
        val DB_VERSION = 1
    }

    val TABLE_NAME = "blog"
    val COLUMN_ID = "_ID"
    val COLUMN_EMAIL = "EMAIL"
    val COLIUMN_NAME = "NAME"
    val COLUMN_PASSWORD  = "PASSWORD"




    constructor(context: Context?, name: String, factory: SQLiteDatabase.CursorFactory?, version: Int) : super(context,name, factory, version)

    constructor(context: Context?) :super(context,DB_NAME,null,DB_VERSION)
    override fun onCreate(sqlDatabase: SQLiteDatabase?) {

        sqlDatabase?.execSQL(  "CREATE TABLE " + TABLE_NAME + "( " + COLUMN_ID + "INTEGER PRIMARY KEY AUTOINCREMENT, "+ COLIUMN_NAME + "STRING, " + COLUMN_EMAIL + "STRING, " + COLUMN_PASSWORD + "STRING " + ");")


    }

    override fun onUpgrade(sqlDatabase: SQLiteDatabase?, p1: Int, p2: Int) {

        sqlDatabase?.execSQL("DROP TABLE IF EXIST " + TABLE_NAME)
        onCreate(sqlDatabase)
        sqlDatabase?.close()


    }

//    constructor(context: Context?, name: String?, factory: SQLiteDatabase.CursorFactory?, version: Int) : super(context, DB_NAME, factory, version)
    // constructor(context: Context?, name: String?, factory: SQLiteDatabase.CursorFactory?, version: Int) : super(context, name, factory, version)






    fun AddUser(user:User)
   {
       val db:SQLiteDatabase = this.writableDatabase
       val values:ContentValues = ContentValues()
       values.put(COLIUMN_NAME,user.name)
       values.put(COLUMN_EMAIL,user.Email)
       values.put(COLUMN_PASSWORD,user.password)
       db.insert(TABLE_NAME,null,values)
   }



    fun checkUser(email: String): Boolean {

        val columns = arrayOf<String>(COLUMN_ID)
        val db = this.readableDatabase
        val selection = COLUMN_EMAIL + " = ?"

        val selectionArgs = arrayOf(email)

        val cursor = db.query(TABLE_NAME, columns, selection, selectionArgs, null, null, null)

        val cursorCount = cursor.count
        cursor.close()
        db.close()
        if (cursorCount > 0) {
            return true
        }
        return  false

    }

    fun checkUser(email: String, password: String): Boolean {

        val columns = arrayOf<String>(COLUMN_ID)
        val db = this.readableDatabase

        val selection = COLUMN_EMAIL + " = ?" + " AND " + COLUMN_PASSWORD

        val selectionArgs = arrayOf(email, password)

        val cursor = db.query(TABLE_NAME,
                columns,
                selection,
                selectionArgs,
                null, null, null)
        val cursorCount = cursor.count

        cursor.close()
        db.close()
         if (cursorCount > 0) {
             return true
        }

        return false

    }
}