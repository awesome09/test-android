package com.walloverss.bloggie

/**
 * Created by Avhinash on 3/4/2018.
 */
class blog(val title:String) {
}