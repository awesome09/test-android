package com.walloverss.bloggie

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.register.*

class Registerr : AppCompatActivity() {

    lateinit var UserDb:UserHelper
   lateinit var em:String
   lateinit var ps:String
   lateinit var nm:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register)
        em = et_email.text.toString()
        ps = et_password.text.toString()
        nm = et_name.text.toString()
        btt_register.setOnClickListener({
            if (isValidate()){
               UserDb.AddUser(User(nm,em,ps))
               val intent = Intent(this,MainActivity::class.java)
               startActivity(intent)

            }
        })
    }

    fun isValidate() :Boolean {

        if(!validEmail())
        {
            return false
        }

        if (!validPassword())
        {
            return false
        }

        if (!validName())
        {
            return false
        }
        Toast.makeText(this, "Register Successful", Toast.LENGTH_SHORT).show()

        return true


    }

    fun validEmail() : Boolean
    {

        if (em.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(em).matches())
        {
            //  layout_email.setError("Enter a valid email address")
            Toast.makeText(this,"Please write correct email", Toast.LENGTH_SHORT).show()
            return false
        }
        else
        {
            layout_email.isErrorEnabled
        }
        return true

    }

    fun validPassword():Boolean
    {

        if (ps.isEmpty() || ps.length <6 || ps.length>12)
        {
            // layout_password.error("Password between 6 and 12 characters ")
            Toast.makeText(this,"Please enter password betwen 6 and 12 characters", Toast.LENGTH_SHORT).show()
            return  false
        }
        else
        {
            layout_password.isErrorEnabled
        }
        return true

    }

    fun validName():Boolean
    {

        if (nm.isEmpty() || nm.length <2)
        {
            // layout_password.error("Password between 6 and 12 characters ")
            Toast.makeText(this,"Please enter your name", Toast.LENGTH_SHORT).show()
            return  false
        }
        else
        {
            layout_password.isErrorEnabled
        }
        return true

    }
}
