package com.walloverss.bloggie

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_content.*

class Content : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_content)

        recycler.layoutManager = LinearLayoutManager(this)
        val blog  = ArrayList<blog>()
        blog.add(blog("Hello"))
        blog.add(blog("Hello Brother"))

        recycler.adapter = BlogAdapter(blog)
    }
}
