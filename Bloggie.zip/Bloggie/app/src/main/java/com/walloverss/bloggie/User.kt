package com.walloverss.bloggie

/**
 * Created by Avhinash on 3/4/2018.
 */
data class User(val name:String,val Email:String,val password:String) {
}